package sam.dayan.samcompose

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * The Service that uses the base URL to
 * retrieve the Authors.
 */
interface AuthorsService {

    /**
     * This is the API call to
     * retrieve the list of authors.
     * The Authors will be returned in the form of a list.
     * @param limit The number of items to retrieve
     * in one call.
     */
    @GET("list")
    fun getAuthors(
        @Query("page") page: Int = 2,
        @Query("limit") limit: Int
    ): Call<List<Author>>
}