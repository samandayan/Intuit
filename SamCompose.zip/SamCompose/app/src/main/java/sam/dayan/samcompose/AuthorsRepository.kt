package sam.dayan.samcompose

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

/**
 * This repository builds the base retrofit
 * to download the list of authors.
 * This will be used in conjunction with AuthorsService
 * to retrieve the list of Launches from the server in the
 * form of a list.
 */
class AuthorsRepository {

    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://picsum.photos/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val service = retrofit.create<AuthorsService>()

    fun getLaunches(limit: Int) = service.getAuthors(limit = limit)
}