package sam.dayan.samcompose

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import coil.compose.rememberAsyncImagePainter
import sam.dayan.samcompose.ui.theme.SamComposeTheme

class MainActivity : ComponentActivity() {
    lateinit var mViewModel: SamViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mViewModel = ViewModelProvider(MainActivity@ this).get(SamViewModel::class.java)
        mViewModel.retrieveAuthors()

        setContent {
            SamComposeTheme {
                AuthorsScreen(mViewModel)
            }
        }
    }

    override fun onBackPressed() {
        if (mViewModel.showDetail)
            mViewModel.showDetail = false
        else
            super.onBackPressed()
    }
}

@Composable
fun AuthorsScreen(viewModel: SamViewModel) {

    if (viewModel.showDetail) {
        ShowAuthorDetail(author = viewModel.author)
    } else {
        ShowAuthorList(viewModel = viewModel)
    }
}

/**
 * This shows the detail of the author
 * such as its name, and the image
 * associated with it.
 */
@Composable
fun ShowAuthorList(viewModel: SamViewModel) {

    LazyColumn {
        items(viewModel.authors) { author ->
            AuthorRow(author, showDetail = { viewModel.showAuthorDetail(author) })
        }
        itemsIndexed(viewModel.authors) { index, item ->
            if (index == viewModel.authors.size - 1) {
                viewModel.retrieveAuthors()
            }
        }
    }
}

@Composable
fun AuthorRow(author: Author, showDetail: (Author) -> Unit) {
    ClickableText(
        text = AnnotatedString("${author.author}"),
        modifier = Modifier.padding(4.dp),
        style = MaterialTheme.typography.h5,
        onClick = {
            Log.i("asdf", author.author.toString())
            showDetail(author)
        })
}

/**
 * This shows the list of the authors
 * which is retrieved from the server
 * at run-time.
 */
@Composable
fun ShowAuthorDetail(author: Author) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "${author.author}",
            modifier = Modifier.padding(bottom = 8.dp),
            style = MaterialTheme.typography.h3
        )

        Image(
            // rememberAsyncImagePainter Does perform caching.
            // The image URL in Author.downloadUrl is not a valid
            // URL pointing to an image. Redirection does not
            // work with dynamic loading.
            // Below is only a placeholder for a valid URL.
            painter = rememberAsyncImagePainter("https://budgetstockphoto.com/samples/pics/dice.jpg"),
            contentDescription = null,
            modifier = Modifier.fillMaxSize()
        )

        author.downloadUrl.let {

        }
    }
}