package sam.dayan.samcompose

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * This is the ViewModel that will use
 * the repository to retrieve the lists of the authors.
 */
class SamViewModel : ViewModel() {
    val repository = AuthorsRepository()

    var authors by mutableStateOf(listOf<Author>())
    var author by mutableStateOf(Author())
    var showDetail by mutableStateOf(false)
    var limit by mutableStateOf(30)

    /**
     * The list of authors is retrieved here.
     * This is incremented by ten so that everytime
     * the user reached the end of the list a new
     * call is made to retrieve the next ten rather than
     * making one call to get the items all at once.
     * This saves bandwidth usage.
     */
    fun retrieveAuthors() {
        viewModelScope.launch {
            repository.getLaunches(limit = limit).enqueue(object : Callback<List<Author>> {
                override fun onResponse(
                    call: Call<List<Author>>,
                    response: Response<List<Author>>
                ) {
                    if (response.body() != null) {
                        authors = response.body()!!
                    }
                    Log.i("asdf", response.body().toString())
                }

                override fun onFailure(call: Call<List<Author>>, t: Throwable) {
                }
            })
            limit += 10
        }
    }

    /**
     * This is used to switch over from the
     * list of authors to the detail pertaining
     * to each author which would include the
     * author name as well as the image associated
     * with it.
     */
    fun showAuthorDetail(author: Author) {
        this.author = author
        showDetail = true
    }
}