package sam.dayan.samcompose

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * The ViewModel logic is tested here.
 * This is to make sure that the detail
 * logic is properly updated and the
 * correct author information is
 * displayed.
 */
class SamTest {
    lateinit var viewModel: SamViewModel

    @Before
    fun setup() {
        viewModel = SamViewModel()
    }

    /**
     * This test is to make sure that the
     * detail will be displayed when a
     * new author is selected.
     */
    @Test
    fun isDetailDisplayed() {
        val author = Author(
            author = "George",
            downloadUrl = "https://budgetstockphoto.com/samples/pics/dice.jpg"
        )
        viewModel.showAuthorDetail(author)
        assertTrue(viewModel.showDetail)
    }

    /**
     * This will check to make sure
     * that the detail author in the
     * ViewModel is correctly updated so that
     * the correct author detail is displayed.
     */
    @Test
    fun checkAuthorDetailInformation() {
        val name = "George"
        val URL = "https://budgetstockphoto.com/samples/pics/dice.jpg"
        val author = Author(author = name, downloadUrl = URL)
        viewModel.showAuthorDetail(author)
        assertEquals("George", viewModel.author.author)
        assertEquals(URL, viewModel.author.downloadUrl)
    }

}